'''
Created on 2019年8月15日

@author: ryefccd
'''


def add_two(num1, num2):
    return num1 + num2


def sub_two(num1, num2):
    return num1 - num2
